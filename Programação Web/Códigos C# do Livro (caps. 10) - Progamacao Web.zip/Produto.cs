﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LojaDepartamentos
{
    public class Produto
    {
        public int IdProduto { get; set; }
        public int Qtde { get; set; }

        public Produto()
        {
            IdProduto = 0;
            Qtde = 0;
        }
        public Produto(int paridproduto, int parqtde)
        {
            IdProduto = paridproduto;
            Qtde = parqtde;
        }
    }
}