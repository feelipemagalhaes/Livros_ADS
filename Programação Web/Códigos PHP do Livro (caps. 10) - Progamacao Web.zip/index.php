<html>
<head></head>
<body>
<?php
	try {
		$conn = new PDO("mysql:host=localhost;dbname=LojaDepartamentos", "root", "");
		echo "Conectado com o banco de dados</br>";
	} catch(PDOException $erro) {
		echo "<strong>ERRO DETECTADO:</strong></br>", $erro->getMessage();
   	}
?>
<div class="cabecalho">
<table>
    <tr><td><img src="logo_loja.jpg"></td></tr>
</table>
</div>

<div class="navbar">
<table class="menudepartamentos"><tr>
<?php
$sqlSelectCommand="SELECT IdDepartamento, Nome ";
$sqlSelectCommand.="FROM Departamento ";
$sqlSelectCommand.="ORDER BY Nome";
$statement = $conn->prepare($sqlSelectCommand);
$statement->execute();
$ds = $statement->fetchAll(PDO::FETCH_ASSOC);
foreach($ds as $row) {
	$tmp_iddepartamento = $row["IdDepartamento"];
	$tmp_nome = $row["Nome"];
	echo "<td><a href=\"index.php?pagina=\"categoria\"&iddepartamento=";
	echo $tmp_idepartamento."\">".$tmp_nome."</a></td>";
}
?>
</tr></table>

<?php
$iddepartamento = $_GET["iddepartamento"];
if(!empty($iddepartamento))
	include("categoria.php");
?>
</div>

<div class="pagina">
<?php
$pagina = $_GET["pagina"];
switch(pagina)
{
	case "produto": include("produto.php"); break;
	case "carrinho": include("carrinho.php"); break;
	case "pedido": include("pedido.php"); break;
	case "final": include("finalizar.php"); break;
}
?>
</div>

<div class="rodape">
<table>
    <tr><td>2017 - Todos os direitos reservados</td></tr>
</table>
</div>

</body>
</html>