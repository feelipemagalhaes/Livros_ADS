<table class="menucategorias"><tr>
<?php
$sqlSelectCommand="SELECT IdCategoria, Nome ";
$sqlSelectCommand.="FROM Categoria ";
$sqlSelectCommand.="WHERE IdDepartamento = ".$iddepartamento;
$statement = $conn->prepare($sqlSelectCommand);
$statement->execute();
$ds = $statement->fetchAll(PDO::FETCH_ASSOC);
foreach($ds as $row) {
	$tmp_idcategoria = $row["IdCategoria"];
	$tmp_nome = $row["Nome"];
	echo "<td><a href=\"index.php?pagina=produto&idcategoria=";
	echo $tmp_idcategoria."\">".$tmp_nome."</a></td>";
}
?>
</tr></table>
