<table class="pagina"><tr>
<?php
$idcategoria = $GET["idcategoria"];
$sqlSelectCommand="SELECT IdProduto, Nome, Valor ";
$sqlSelectCommand.="FROM Produto ";
$sqlSelectCommand.="WHERE IdCategoria = ".$idcategoria;
$statement = $conn->prepare($sqlSelectCommand);
$statement->execute();
$ds = $statement->fetchAll(PDO::FETCH_ASSOC);
$reg = 0;
foreach($ds as $row) {
	if($reg % 4 == 0)
		echo "</tr><tr>";
	$tmp_idproduto = $row["IdProduto"];
	$tmp_nome = $row["Nome"];
	$tmp_valor = number_format($row["Valor"], 2, ',', '.');
	$sqlSelectCommand="SELECT Arquivo ";
	$sqlSelectCommand.="FROM ImagemProduto ";
	$sqlSelectCommand.="WHERE IdProduto = ".$tmp_idproduto." ";
	$sqlSelectCommand.="AND IdSequencia = 1";
	$statementimagem = $conn->prepare($sqlSelectCommand);
	$statementimagem->execute();
	$dsimagem = $statementimagem->fetch(PDO::FETCH_ASSOC);
	$tmp_imagem = $dsimagem["Arquivo"];
	echo "<td>";
	echo "<img src=\"images/".$tmp_imagem."\"><br>";
	echo $tmp_nome."<br>";
	echo $tmp_valor."<br>";
	echo "<a href=\"index.php?pagina=adicionar&idproduto=";
	echo $tmp_idproduto."\"><img src=\"../images/btncomprar.png\"></a>";
	echo "/<td>";
	$reg++;
}
?>
</tr></table>
