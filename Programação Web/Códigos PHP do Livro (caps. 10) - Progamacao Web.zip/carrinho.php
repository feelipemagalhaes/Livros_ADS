<?php
if(count($_SESSION["carrinho"]) == 0)
	echo "Carrinho vazio!";
else
{
	echo "<table class=\"carrinho\"><tr>";
	echo "<th>Imagem</th><th>Descri��o</th><th>Quantidade</th>";
	echo "<th>Valor Unit�rio</th><th>Valor Total</th><th>Remover</th>";
	echo "</tr>";
	$tmp_total = 0;
	foreach($_SESSION["carrinho"] as $tmp_idproduto => $tmp_qtde) {
		echo "<tr>";
		$sqlSelectCommand="SELECT Arquivo ";
		$sqlSelectCommand.="FROM ImagemProduto ";
		$sqlSelectCommand.="WHERE IdProduto = ".$tmp_idproduto." ";
		$sqlSelectCommand.="AND IdSequencia = 1";
		$statement = $conn->prepare($sqlSelectCommand);
		$statement->execute();
		$ds = $statement->fetch(PDO::FETCH_ASSOC);
		$tmp_imagem = $ds["Arquivo"];
		echo "<td><img src=\"".$tmp_imagem."\"></td>";
		$sqlSelectCommand="SELECT Nome, Valor ";
		$sqlSelectCommand.="FROM Produto ";
		$sqlSelectCommand.="WHERE IdProduto = ".$tmp_idproduto." ";
		$statement = $conn->prepare($sqlSelectCommand);
		$statement->execute();
		$ds = $statement->fetch(PDO::FETCH_ASSOC);
		$tmp_nome = $ds["Nome"];
		$tmp_valor_u = number_format($ds["Valor"], 2, ',', '.');
		$tmp_valor_t = number_format($ds["Valor"] * $tmp_qtde, 2, ',', '.');
		$tmp_total += $ds["Valor"] * $tmp_qtde;
		echo "<td>".$tmp_nome."</td><td>".$tmp_qtde."</td>";
		echo "<td>".$tmp_valor_u."</td><td>".$tmp_valor_t."</td>";
		echo "<td><a href=\"index.php?pagina=remover&idproduto=".$tmp_idproduto."\">";
		echo "<img src=\"../images/btnremover.png\"></a></td>";
		echo "</tr>";
	}
	echo "</table>";
	$tmp_total = number_format($tmp_total, 2, ',', '.');
	echo "<tr><td></td><td></td><td></td>";
	echo "<td>Total:</td><td>".$_tmp_total."</td></tr>";
	echo "<a href=\"index.php?pagina=finalizar\">";
	echo "<img src=\"../images/btnfinalizar.png\"></a></td>";
}
?>