<?php
session_start();
if(!isset($_SESSION["carrinho"]))
	$_SESSION["carrinho"] = array();
$idproduto = intval($_GET["idproduto"]);
if(!isset($_SESSION["carrinho"][$idproduto]))
	$_SESSION["carrinho"][$idproduto] = 1;
else
	$_SESSION["carrinho"][$idproduto] += 1;
header("../index.php?pagina=carrinho",301);
?>