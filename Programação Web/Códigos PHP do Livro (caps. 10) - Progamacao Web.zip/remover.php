<?php
session_start();
$idproduto = intval($_GET["idproduto"]);
if(isset($_SESSION['carrinho'][$idproduto]))
	unset($_SESSION['carrinho'][$idproduto]);
header("../index.php?pagina=carrinho",301);
?>
