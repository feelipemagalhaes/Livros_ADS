<?php
	setcookie('usuEmail');
	setcookie('usuSenha');
	setcookie('usuTipo');
	header('Location: index.php');	
?>